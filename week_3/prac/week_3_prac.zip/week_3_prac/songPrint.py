class Song: 
    def __init__(self, title, artist, duration, genre, album):
        self.title = title
        self.artist = artist
        self.duration = duration
        self.genre = genre
        self.album = album
    def ply(self):
        print(self.title)
        print(self.artist)
        print(self.duration)
        print(self.genre)


        
